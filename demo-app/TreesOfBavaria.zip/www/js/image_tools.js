"use strict";

var Thumbnail = {
	create : function(config){

		var config = config || {};

		var self = Object.create(this);

		self.config = {
			quality : 1.00,
			maxWidth : 100,
			maxHeight : 100,
			imageSize : "cover"
		}

		for (var key in config){
			self.config[key] = config[key];
		}

		return self;
	},

	as_data_url : function(image_src, onsuccess, onerror){
		var self = this;

		self._load_image(image_src, function(loaded_image){

			// scale the loaded image in a canvas
			var thumb_canvas = self._get_thumbnail_canvas(loaded_image);
			var image_data = thumb_canvas.toDataURL('image/jpeg', self.config.quality);
			
			onsuccess(image_data);

		}, onerror)

	},

	as_blob : function(image_src, onsuccess, onerror){

		var self = this;

		self._load_image(image_src, function(loaded_image){

			// scale the loaded image in a canvas
			var thumb_canvas = self._get_thumbnail_canvas(loaded_image);
			thumb_canvas.toBlob(onsuccess, 'image/jpeg');

		}, onerror)

	},

	// image can be a valid URI or a data: url
	// some browser use fakepath which makes filereader necessary, in this case image_src is an object
	_load_image : function(image_src, onsuccess, onerror){
		
		var self = this;

		if (typeof(image_src) == "object"){
			self._load_image_from_reader(image_src, onsuccess, onerror);
		}

		else {

			// first, try to simply load the image
			var image = new Image();

			image.onload = function(){
				onsuccess(image);
			}
			
			image.onerror = function(){

				if (typeof(onerror) == "function"){
					onerror(e);
				}
				else {
					alert("error loading the image " + image_src);
				}
			}

			image.src = image_src;
		}

	},

	_load_image_from_reader : function(blob, onsuccess, onerror){
		var self = this;

		var reader = new FileReader();
		reader.onloadend = function(event){
			self._load_image(event.target.result, onsuccess, onerror);
		}

		reader.onerror = function(e){
			if (typeof(onerror) == "function"){
				onerror(e);
			}
			else {
				alert("error loading the image from a blob");
			}
		}
		reader.readAsDataURL(blob);
	},


	_get_thumbnail_canvas : function(loaded_image){

		var self = this

		var canvas = document.createElement("canvas");
		canvas.width = loaded_image.width;
		canvas.height = loaded_image.height;
		canvas.getContext("2d").drawImage(loaded_image, 0, 0, canvas.width, canvas.height);

		// reduce the image size in steps for better results
		while (canvas.width >= (2 * self.config.maxWidth) && canvas.height >= (2 * self.config.maxHeight)) {
		    canvas = self._get_half_scale_canvas(canvas);
		}

		// the image is now larger than self.config.maxWidth and/or self.config.maxHeight
		// depending on self.config.imageSize == cover or contain, perform the next scale

		canvas = self._get_scaled_canvas(canvas);
		
		// the image is now downscaled, but still has its original aspect ratio
		// if self.config.imageSize == cover, cropping is necessary
		if (self.config.imageSize == "cover"){
			canvas = self._get_cropped_canvas(canvas);
		}

		return canvas;

	},

	_get_cropped_canvas : function(canvas){
		var self = this;

		// determine topleft start of crop (sx,sy)
		var sx = Math.abs( (canvas.width/2) - (self.config.maxWidth/2));
		var sy = Math.abs( (canvas.height/2) - (self.config.maxHeight/2));

		var cropped_canvas = document.createElement("canvas");
		cropped_canvas.width = self.config.maxWidth;
		cropped_canvas.height = self.config.maxHeight;

		cropped_canvas.getContext("2d").drawImage(canvas, sx, sy, self.config.maxWidth, self.config.maxHeight, 0, 0, self.config.maxWidth, self.config.maxHeight);

		return cropped_canvas;
	},


	_get_scale_factor : function(canvas){

		var self = this;

		// check differences
		var wdiff = Math.abs(self.config.maxWidth - canvas.width),
			hdiff = Math.abs(self.config.maxHeight - canvas.height);

		if (self.config.imageSize == "contain"){
			// contain -> the larger difference determines the scale factor
			if (wdiff >= hdiff){
				var scale_factor = self.config.maxWidth / canvas.width;
			}
			else {
				var scale_factor = self.config.maxHeight / canvas.height;
			}
		}
		else {
			// cover -> the smaller difference determines the scale factor
			if (wdiff <= hdiff){
				var scale_factor = self.config.maxWidth / canvas.width;
			}
			else {
				var scale_factor = self.config.maxHeight / canvas.height;
			}
		}

		return scale_factor;

	},

	_get_scaled_canvas : function(canvas){

		var self = this;

		var scaled_canvas = document.createElement("canvas");
		
		var scale_factor = self._get_scale_factor(canvas);

		scaled_canvas.width = canvas.width * scale_factor;
		scaled_canvas.height = canvas.height * scale_factor;
	
		scaled_canvas.getContext('2d').drawImage(canvas, 0, 0, scaled_canvas.width, scaled_canvas.height);

		return scaled_canvas;

	},

	// reduce the image size in steps for better results
	_get_half_scale_canvas : function(canvas) {
		var halfCanvas = document.createElement("canvas");
		halfCanvas.width = canvas.width / 2;
		halfCanvas.height = canvas.height / 2;

		halfCanvas.getContext('2d').drawImage(canvas, 0, 0, halfCanvas.width, halfCanvas.height);

		return halfCanvas;
	}

}


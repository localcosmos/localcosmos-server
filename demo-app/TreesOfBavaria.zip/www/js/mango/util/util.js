"use strict";

function validate_uuid(str){
	var pattern = new RegExp('^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$', 'i');
	return pattern.test(str);
}


function validate_slug(str){
	var pattern = new RegExp('^[A-Za-z0-9]+(?:-[A-Za-z0-9]+)*$');
	return pattern.test(str);
}


/*
* ios only uses CELL without _2G etc
*/
function getNetworkState(){

	if (navigator.connection.hasOwnProperty("type")){
		var network_state = navigator.connection.type;
	}
	else {
		// chromium: navigator.connection == {}
		var network_state = "ETHERNET";
	}

	// Connection.CELL_2G.toLowerCase(), is offline
	var internet = [Connection.ETHERNET.toLowerCase(), Connection.WIFI.toLowerCase(), Connection.CELL_3G.toLowerCase(), Connection.CELL_4G.toLowerCase(), Connection.CELL.toLowerCase()];
	var nointernet = [Connection.UNKNOWN.toLowerCase(), Connection.NONE.toLowerCase(), Connection.CELL_2G.toLowerCase()];

	if (internet.indexOf(network_state.toLowerCase()) >= 0){
		return "online";
	}
	else {
		return "offline";
	}
}


// FILE UTIL
var FileUtil = {

	_onerror : function(e){
		if (typeof e === "string" || e instanceof String){
			var message = e;
		}
		else {
			var message = JSON.stringify(e);
		}
		alert("[FILE PLUGIN ERROR] " + message);
	},

	save : function(directory_name, fileObj, onsuccess, onerror){
		var onerror = onerror || this._onerror;

		window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, function (fs) {

			fs.root.getDirectory(directory_name, { create: true }, function (dirEntry) {

				var filename = fileObj.name;

				if (fileObj.hasOwnProperty("filename")){
					var filename = fileObj.filename;
				}

				console.log("storing file " + filename);

				dirEntry.getFile(filename, { create: true, exclusive: false }, function (fileEntry) {

					fileEntry.createWriter(function(fileWriter) {

						fileWriter.onwriteend = function() {
							console.log("[FileUtil] stored file: " + fileEntry.name);
							onsuccess(fileEntry);
						};

						fileWriter.onerror = onerror;

						fileWriter.write(fileObj);

					}, onerror);

				}, onerror);

			}, onerror);

		}, onerror);

	},

	remove : function(cdvfilepath, onsuccess, onerror){

		var onerror = onerror || this._onerror;

		var path_parts = cdvfilepath.split("/");

		var filename = path_parts.pop();
		var directory = path_parts.join("/");

		window.resolveLocalFileSystemURL(directory, function (dirEntry) {

			dirEntry.getFile(filename, {create: false}, function (fileEntry) {

		        fileEntry.remove(onsuccess, onerror);

		    }, function(error){
				if (error.code == 1){

					console.log("[FileUtil] did not remove file because it was not found: " + cdvfilepath);

					// file not found
					onsuccess();
				}
				else {
					onerror(error);
				}
				
			});

		}, onerror);

	},

	get : function(path, onsuccess, onerror){

		var onerror = onerror || this._onerror;

		window.resolveLocalFileSystemURL(path, function(fileEntry){

			fileEntry.file(function(file){
				onsuccess(file);
			}, onerror);

		}, onerror);
	}

};

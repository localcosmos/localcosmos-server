"use strict";

var upstart = {

	run : function(){

		var self = this;

		console.log("[UPSTART] running on " + device.platform);

		// localize from a json dict
		Handlebars.registerHelper('localize', function (obj) {
			var result = obj[app.language];
			return new Handlebars.SafeString(result);
		});

		Handlebars.registerHelper('vernacular', function (i18n_key) {

			// ȵ is the namespace separator
			var lookup_key = 'plainȵ' + i18n_key;

			var result = i18next.t(lookup_key);

			if (result == i18n_key){
				return "";
			}
			return new Handlebars.SafeString(result);
		});

		Handlebars.registerHelper('date', function (date_obj) {
			if (!date_obj){
				return '';
			}
			return new Handlebars.SafeString(date_obj.toLocaleDateString());
		});

		Handlebars.registerHelper('verbose_datetime', function (str) {

			var date = new Date(str);

			return new Handlebars.SafeString(date.toLocaleString());
		});

		// first check requirements
		if ("GenericForm" in app_features || "ButtonMatrix" in app_features){
			app.requires_geolocation = true;	
		}

		self._load_theme(function(){

			console.log("[UPSTART] theme initialized");

			self._load_language(function(){

				self._load_handlebars_helpers();

				self._render_skeleton(function(){

					// load ModalDialog immediately after the skeleton
					window.modalDialog = ModalDialog.create("ModalDialog");

					// load ModalProgress
					window.modalProgress = ModalProgress.create("ModalProgress");

					// observation forms
					if ("GenericForm" in app_features){
						self._init_observation_forms();
					}

					// init geolocation
					if (app.requires_geolocation == true){
						AppGeolocation.start_watching();
					}

					self._load_mango(function(){

						// sidemenu requires mango_session.user
						load_sidemenu();

						// needs initialized mango
						self._update_device_uuid(function(){

							console.log("[UPSTART] finished loading LC app");

						});

					});

				});	

			});		

		});

	},

	_load_language : function(callback){
		
		var language = navigator.language.substring(0,2).toLowerCase();

		if (settings.LANGUAGES.indexOf(language) >=0){
			app.language = language;
		}
		else if (settings.LANGUAGES.indexOf("en") >=0){
			app.language = "en";
		}
		else {
			app.language = settings.PRIMARY_LANGUAGE;
		}
		callback();
	},

	_load_mango : function(callback){

		mango.init({
			"ajaxify_container" : document.getElementById("app"),
			"container" : document.getElementById("content"),
			"_on_new_page" : function(view_identifier, args, kwargs){
				// load the App bar
				Appbar.load(view_identifier, args, kwargs);
				// check if a custom callback function is in kwargs
			}

		}, callback);

	},

	_update_device_uuid : function(callback){
		// prevent creating a ton of uuids for each time the user uses a browser
		// this does not replace server-side assignment of users to a dataset
		// getting the browser client_id might fail - a dataset might be sent with a new client_id that is not yet linked to the uploader
		lcapi.get_browser_client_id(function(response){
			device.uuid = response.client_id;
			callback();
		}, callback);
	},

	_load_theme : function(callback){

		ajax.getJSON("themes/" + settings.THEME + "/config.json", {}, function(theme_config){

			app.theme = theme_config;

			// load theme specific css files

			each(app.theme.css, function(css_relative_filepath, iterate){

				var css_filepath = "themes/" + settings.THEME + "/" + css_relative_filepath; 

				var link = document.createElement("link");
				link.setAttribute("rel", "stylesheet");
				link.setAttribute("type","text/css");

				link.onload = function(){
					link.onload = null;
					iterate();
				}

				link.setAttribute("href", css_filepath);

				document.head.appendChild(link);

			},

			function(){

				// load theme specific js files
				// make sure script x+1 is loaded after x has finished loading -> async
				each(app.theme.js, function(script_relative_filepath, iterate){

					var script_filepath = "themes/" + settings.THEME + "/" + script_relative_filepath;

					var script = document.createElement("script");
					script.async = true;
					script.setAttribute("type","text/javascript");

					script.onload = function() {
						// Cleanup onload handler
						script.onload = null;

						iterate();
					}

					script.src = script_filepath;

					document.head.appendChild(script);

				}, callback);

			});

		});
	},

	_render_skeleton : function (callback){

		// we need the t helper in the skeleton
		mango.init_i18n();

		var context = {
			"app_requires_geolocation" : app.requires_geolocation
		};

		ajax.GET("themes/" + settings["THEME"] + "/templates/skeleton.html", {}, function(template){
			var skeleton = Handlebars.compile( template )(context);
			document.getElementById("app").innerHTML = skeleton;

			callback();
		});
		
	},

	_load_handlebars_helpers : function() {

		Handlebars.registerHelper("themeFolder", function () {
		    return "themes/" + settings.THEME + "/";
		});		

	},

	_init_observation_forms : function(callback){
		/* Create form prototypes for all forms in settings */

		var observation_forms = app_features["GenericForm"]["list"];

		each(observation_forms, function(form_link, iterate){
			ajax.GET(form_link["path"], {}, function(content){

				// create window[uuid] as a Form prototype
				var form_definition  = JSON.parse(atob(content));

				window[form_definition["uuid"]] = createObservationFormFromJSON(form_definition);

				iterate();
			});
		});

	},
	_load_taxonomy : function(){
		// loads the vernacular taxonomy
		var path = app_features.BackboneTaxonomy.vernacular[app.language];

		ajax.getJSON(path, {}, function(taxa){
			window.Vernacular = taxa;
		});
	}

}

/* add your listeners here */

var listeners = {
	"NatureGuideView" : {}
};


document.addEventListener('identification_complete', function(event){
	// hide filters is hideable
	if (typeof(OverlayView.close_current_overlay) == "function"){
		OverlayView.close_current_overlay();
	}
});

{ 
	toolbar: ['bold', 'italic', '|', 'undo', 'redo']
}

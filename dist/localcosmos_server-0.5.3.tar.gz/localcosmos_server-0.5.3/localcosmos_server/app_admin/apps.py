from django.apps import AppConfig


class AppAdminConfig(AppConfig):
    name = 'app_admin'

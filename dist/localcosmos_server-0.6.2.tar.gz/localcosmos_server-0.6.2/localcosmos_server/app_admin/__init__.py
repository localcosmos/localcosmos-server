#default_app_config = 'localcosmos_server.app_admin.apps.AppAdminConfig'

name = 'localcosmos_server'

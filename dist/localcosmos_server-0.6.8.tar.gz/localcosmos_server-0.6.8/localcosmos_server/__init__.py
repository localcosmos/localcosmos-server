name = 'localcosmos_server'
VERSION = '0.6.8'

from django.apps import AppConfig


class DatasetsConfig(AppConfig):
    name = 'datasets'

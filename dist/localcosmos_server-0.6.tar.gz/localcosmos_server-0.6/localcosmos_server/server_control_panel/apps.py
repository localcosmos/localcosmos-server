from django.apps import AppConfig


class ServerControlPanelConfig(AppConfig):
    name = 'server_control_panel'

from django.apps import AppConfig


class OnlineContentConfig(AppConfig):
    name = 'online_content'

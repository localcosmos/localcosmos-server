name = 'localcosmos_server'
VERSION = '0.7.1'
